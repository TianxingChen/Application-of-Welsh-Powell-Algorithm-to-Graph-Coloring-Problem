import copy
from functools import cmp_to_key

global max_degree
max_degree = -1


class NODE:
    def __init__(self, number, sub_matrix):
        global max_degree
        self.node_number = number
        self.connect = []
        self.color = -1  # Which means this node haven't been colored
        for i in range(len(sub_matrix)):
            if sub_matrix[i]:
                self.connect.append(i)
        self.degree = len(self.connect)  # The number of nodes connect to it
        max_degree = max(max_degree, self.degree)


def compare(x, y):  # Sort in descending order by degree
    if x.degree < y.degree:
        return 1
    elif x.degree > y.degree:
        return -1
    return 0


node_size = -1
AdjacencyMatrix, node = [], []

node_size = int(input())
for i in range(node_size):  # Load in AdjacencyMatrix
    AdjacencyMatrix.append([])
    line = input()
    for j in range(node_size):
        AdjacencyMatrix[i].append(int(line[j]))


for i in range(node_size):  # Construct new node
    node.append(NODE(i, AdjacencyMatrix[i]))


##################################
###---Welsh-Powell Algorithm---###
##################################
color_kind = 0

SortedNode = copy.deepcopy(node)
SortedNode = sorted(SortedNode, key=cmp_to_key(compare))  # Sort in descending order by degree

while SortedNode:
    color_kind += 1
    i = 0
    while i < len(SortedNode):
        check = True
        for j in range(len(SortedNode[i].connect)):
            if node[SortedNode[i].connect[j]].color == color_kind:
                check = False
                break
        if check:
            node[SortedNode[i].node_number].color = color_kind
            SortedNode.remove(SortedNode[i])
            i -= 1
        i += 1

print("图中结点最大度：" + str(max_degree) + "\n根据Welsh-Powell算法分配出来的最大颜色数量："+str(color_kind))

print("详细分配情况：")
for i in range(node_size):
    print(str(i+1)+":"+str(node[i].color))

print("\n颜色对应结点情况：")
for i in range(color_kind):
    s = str(i+1) + ": "
    for j in range(node_size):
        if node[j].color == i+1:
            s += " " + str(node[j].node_number+1)
    print(s)

"""
test case:

30
011100000000000000000000000000
101011000000000000000000000000
110110000000000000000000000000
101011111000000000000000000000
011101001110000000000000000000
010010000011000000000000000000
000100011000000000000000000000
000100101000000001100000011100
000100110100000111000000000000
000010001010001100000000000000
000011000101001000000000000000
000001000010011000000000000000
000000000000010000000000000000
000000000001101000011000000000
000000000111010100010000000000
000000001100001010010100000000
000000001000000101100101100000
000000011000000010100000000000
000000010000000011000010000010
000000000000011100001110000000
000000000000010000010010000001
000000000000000110010011100000
000000000000000000011101000000
000000000000000000000110100000
000000000000000010100101000000
000000010000000000100000001000
000000010000000000000000010100
000000010000000000000000001000
000000000000000000100000000000
000000000000000000001000000000

----------
2 3 4 -1
1 3 5 6 -1
1 2 4 5 -1
1 3 5 6 7 8 9 -1
2 3 4 6 9 10 11 -1
2 5 11 12 -1
4 8 9 -1
4 7 9 18 19 26 27 28 -1
4 7 8 10 16 17 18 -1
5 9 11 15 16 -1
5 6 10 12 15 -1
6 11 14 15 -1
14 -1
12 13 15 20 21 -1
10 11 12 14 16 20 -1
9 10 15 17 20 22 -1
9 16 18 19 22 24 25 -1
8 9 17 19 -1
8 17 18 23 29 -1
14 15 16 21 22 23 -1
14 20 23 30 -1
16 17 20 23 24 25 -1
20 21 22 24 -1
22 23 25 -1
17 19 22 24 -1
8 19 27 -1
8 26 28 -1
8 27 -1
19 -1
21 -1
19 -1
21 -1

"""
